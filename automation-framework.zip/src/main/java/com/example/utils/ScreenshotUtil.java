package com.example.utils;
public class ScreenshotUtil {}