package com.example.reporting;
public class ExtentManager {}