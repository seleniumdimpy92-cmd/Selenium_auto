package com.example.tests.ui.tests;
public class LoginSuccessTest {}