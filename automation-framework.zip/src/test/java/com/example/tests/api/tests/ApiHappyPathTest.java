package com.example.tests.api.tests;
public class ApiHappyPathTest {}