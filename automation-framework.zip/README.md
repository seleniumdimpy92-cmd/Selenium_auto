# Automation Framework

Java TestNG + Selenium + RestAssured example.